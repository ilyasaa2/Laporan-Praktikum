PI = 3.14159

def luas_lingkaran(radius):
    return PI * radius * radius

def luas_persegi(sisi):
    return sisi * sisi